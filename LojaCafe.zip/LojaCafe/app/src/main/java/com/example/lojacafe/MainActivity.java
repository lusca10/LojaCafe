package com.example.lojacafe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent sendEmail = new Intent(Intent.ACTION_SEND);

                // Tipo do conteúdo.
                sendEmail.setType("text/plain");

                // Para passar os destinatários deve-se utilizar um array com
                // os endreços de e-mails.
                String[] addresses = {"cafe.do.ifc.concordia@gmail.com"};
                sendEmail.putExtra(Intent.EXTRA_EMAIL, addresses);

                // Corpo do e-mail.
                sendEmail.putExtra(Intent.EXTRA_TEXT, "Olá, quero um café!");

                // Assunto do e-mail.
                sendEmail.putExtra(Intent.EXTRA_SUBJECT, "Café!");

                // Verifica se existe algum app que resolve a intent
                if (sendEmail.resolveActivity(getPackageManager()) != null) {

                    // Inicia a intent
                    startActivity(sendEmail);

                    Log.i("E-mail", "Enviei o intent!");
                }
                Log.i("E-mail", "Botão pressionado!");

            }
        });
    }
}
